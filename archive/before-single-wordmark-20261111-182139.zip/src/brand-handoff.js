import { clamp, segment, cubicInOut } from './pluto-hero-state.js';

// One visual wordmark travels from the landscape into the persistent header.
export function initBrandHandoff(root, getMotion) {
 const source=root.querySelector('.ph-destination-word');
 const caption=root.querySelector('.ph-landing-caption');
 const target=document.querySelector('.site-header .brand-wordmark');
 const flight=document.createElement('span');flight.className='ph-brand-flight';flight.textContent=target.textContent;flight.setAttribute('aria-hidden','true');document.body.append(flight);
 let entry=0,lastTravel=-1,lastRaw=0,raf=0,disposed=false,origin=null,destination=null,rootTop=0,distance=1;
 const blend=(a,b,t)=>a+(b-a)*t;
 function measure(){
  if(disposed)return;
  rootTop=root.getBoundingClientRect().top+scrollY;
  const from=source.getBoundingClientRect(),to=target.getBoundingClientRect(),style=getComputedStyle(source);
  origin={x:from.left,y:from.top+scrollY-rootTop,width:from.width,height:from.height};
  destination={x:to.left,y:to.top,width:to.width,height:to.height};
  // Complete the handoff early, while the landscape is still on screen.
  distance=Math.min(root.clientHeight*.38,360);
  flight.style.fontFamily=style.fontFamily;flight.style.fontSize=style.fontSize;flight.style.fontWeight=style.fontWeight;flight.style.letterSpacing=style.letterSpacing;flight.style.lineHeight=style.lineHeight;flight.style.color=style.color;
 }
 function draw(){
  raf=0;if(disposed)return;
  if(!origin||!destination)measure();
  const raw=clamp((scrollY-rootTop)/distance),progress=getMotion()?cubicInOut(raw):Number(raw>.12);
  if(lastRaw===0&&raw>0)measure();lastRaw=raw;
  const dock=getMotion()?segment(raw,.88,1):progress;
  const isFlying=entry>.01&&progress>0&&progress<1;
  target.style.opacity=String(1-entry*(1-dock));
  source.style.opacity=String(1-segment(progress,0,.025));
  caption.style.opacity=String(segment(lastTravel,.66,.8)*(1-segment(raw,0,.24)));
  flight.style.opacity=isFlying?String(entry*(1-dock)):'0';
  if(entry>.01&&origin.width>0){
   const scale=blend(1,destination.width/origin.width,progress);
   const x=blend(origin.x,destination.x,progress),y=blend(origin.y,destination.y,progress);
   flight.style.transform=`translate3d(${x}px,${y}px,0) scale(${scale})`;
  }
  root.dataset.brandHandoff=raw===0?'landscape':raw===1?'navbar':'travelling';
 }
 const schedule=()=>{if(!raf&&!disposed)raf=requestAnimationFrame(draw);};
 function refresh(){measure();schedule();}
 window.addEventListener('scroll',schedule,{passive:true});window.addEventListener('resize',refresh,{passive:true});document.addEventListener('icypluto:theme',refresh);
 const observer=new ResizeObserver(refresh);observer.observe(source);observer.observe(target);
 document.fonts.ready.then(()=>{if(!disposed)refresh();});
 return {
  update(travel){const next=segment(travel,.36,.78);entry=next;if(travel!==lastTravel){lastTravel=travel;if(travel===1)measure();}draw();},
  refresh,
  dispose(){disposed=true;cancelAnimationFrame(raf);observer.disconnect();window.removeEventListener('scroll',schedule);window.removeEventListener('resize',refresh);document.removeEventListener('icypluto:theme',refresh);flight.remove();source.style.removeProperty('opacity');caption.style.removeProperty('opacity');target.style.removeProperty('opacity');}
 };
}
